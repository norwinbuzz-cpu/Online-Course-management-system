<?php
require __DIR__ . '/config.php';

$q = trim((string)($_GET['q'] ?? ''));
$department = trim((string)($_GET['department'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));

$stats = [
    'total' => (int)$pdo->query('SELECT COUNT(*) FROM employees')->fetchColumn(),
    'active' => (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE employment_status = 'Active'")->fetchColumn(),
    'departments' => (int)$pdo->query('SELECT COUNT(DISTINCT department) FROM employees')->fetchColumn(),
    'on_leave' => (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE employment_status = 'On Leave'")->fetchColumn(),
];

$sql = 'SELECT * FROM employees WHERE 1=1';
$params = [];
if ($q !== '') {
    $sql .= ' AND (employee_code LIKE :q OR first_name LIKE :q OR last_name LIKE :q OR email LIKE :q OR designation LIKE :q)';
    $params['q'] = '%' . $q . '%';
}
if ($department !== '') {
    $sql .= ' AND department = :department';
    $params['department'] = $department;
}
if (in_array($status, ['Active', 'On Leave', 'Inactive'], true)) {
    $sql .= ' AND employment_status = :status';
    $params['status'] = $status;
}
$sql .= ' ORDER BY id DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();
$departments = $pdo->query('SELECT DISTINCT department FROM employees ORDER BY department')->fetchAll(PDO::FETCH_COLUMN);
$notice = take_flash();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>PeopleDesk | Employee Management</title><link rel="stylesheet" href="assets/style.css">
</head>
<body>
<aside class="sidebar">
  <a class="brand" href="index.php"><span class="brand-mark">P</span><span>PeopleDesk<small>EMPLOYEE PORTAL</small></span></a>
  <div class="nav-label">WORKSPACE</div>
  <a class="nav-link active" href="index.php"><span>▦</span> Dashboard</a>
  <a class="nav-link" href="#employee-list"><span>♙</span> Employees</a>
  <a class="nav-link" href="employee_form.php"><span>＋</span> Add employee</a>
  <div class="sidebar-bottom"><div class="avatar">HR</div><div><strong>HR Administrator</strong><small>Local demo account</small></div></div>
</aside>
<main class="main">
  <header class="topbar"><div><span class="breadcrumb">Workspace /</span> <strong>Dashboard</strong></div><span class="date-chip"><?= e(date('d M Y')) ?></span></header>
  <section class="welcome"><div><div class="eyebrow">PEOPLE OVERVIEW</div><h1>Employee dashboard</h1><p>Manage your people, teams and employee records in one place.</p></div><a class="primary-btn" href="employee_form.php">＋ Add employee</a></section>
  <?php if ($notice): ?><div class="alert <?= e($notice['type']) ?>"><?= e($notice['message']) ?></div><?php endif; ?>
  <section class="stats">
    <article class="stat-card"><div class="stat-icon purple">♙</div><div class="stat-label">Total employees</div><div class="stat-number"><?= $stats['total'] ?></div><div class="stat-foot">All employee records</div></article>
    <article class="stat-card"><div class="stat-icon green">✓</div><div class="stat-label">Active employees</div><div class="stat-number"><?= $stats['active'] ?></div><div class="stat-foot">Currently active</div></article>
    <article class="stat-card"><div class="stat-icon blue">▦</div><div class="stat-label">Departments</div><div class="stat-number"><?= $stats['departments'] ?></div><div class="stat-foot">Across the organisation</div></article>
    <article class="stat-card"><div class="stat-icon orange">◷</div><div class="stat-label">On leave</div><div class="stat-number"><?= $stats['on_leave'] ?></div><div class="stat-foot">Currently on leave</div></article>
  </section>
  <section class="panel" id="employee-list">
    <div class="panel-heading"><div><h2>Employee directory</h2><p>Search and manage employee information.</p></div><span class="count-pill"><?= count($employees) ?> records</span></div>
    <form class="filters" method="get" action="index.php">
      <div class="search-box"><span>⌕</span><input type="search" name="q" value="<?= e($q) ?>" placeholder="Search name, ID, email or role"></div>
      <select name="department"><option value="">All departments</option><?php foreach ($departments as $d): ?><option value="<?= e($d) ?>" <?= $department === $d ? 'selected' : '' ?>><?= e($d) ?></option><?php endforeach; ?></select>
      <select name="status"><option value="">All statuses</option><?php foreach (['Active','On Leave','Inactive'] as $s): ?><option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
      <button class="filter-btn" type="submit">Filter</button><a class="reset-link" href="index.php">Reset</a>
    </form>
    <div class="table-wrap"><table><thead><tr><th>EMPLOYEE</th><th>EMPLOYEE ID</th><th>DEPARTMENT</th><th>DESIGNATION</th><th>JOINING DATE</th><th>STATUS</th><th>ACTIONS</th></tr></thead>
    <tbody>
    <?php if (!$employees): ?><tr><td colspan="7" class="empty">No employees found. Try changing your filters or add a new employee.</td></tr><?php endif; ?>
    <?php foreach ($employees as $employee): $initials = strtoupper(substr($employee['first_name'],0,1) . substr($employee['last_name'],0,1)); ?>
      <tr>
        <td><div class="person"><span class="person-avatar"><?= e($initials) ?></span><span><strong><?= e($employee['first_name'] . ' ' . $employee['last_name']) ?></strong><small><?= e($employee['email']) ?></small></span></div></td>
        <td><span class="employee-code"><?= e($employee['employee_code']) ?></span></td>
        <td><?= e($employee['department']) ?></td><td><?= e($employee['designation']) ?></td>
        <td><?= e(date('d M Y', strtotime($employee['joining_date']))) ?></td>
        <td><span class="status <?= strtolower(str_replace(' ','-', $employee['employment_status'])) ?>"><?= e($employee['employment_status']) ?></span></td>
        <td><div class="actions"><a href="employee_form.php?id=<?= (int)$employee['id'] ?>" title="Edit employee">Edit</a>
        <form method="post" action="delete_employee.php" onsubmit="return confirm('Delete this employee record? This action cannot be undone.');">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$employee['id'] ?>"><button class="delete-link" type="submit">Delete</button>
        </form></div></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <div class="panel-footer">Showing <?= count($employees) ?> matching employee record(s)</div>
  </section>
  <footer class="footer">PeopleDesk Employee Management System <span>PHP · MySQL · HTML · CSS</span></footer>
</main>
</body></html>

<?php
require __DIR__ . '/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php'); exit;
}
verify_csrf();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    flash('Invalid employee record.', 'error');
    header('Location: index.php'); exit;
}
$stmt = $pdo->prepare('DELETE FROM employees WHERE id = ?');
$stmt->execute([$id]);
flash($stmt->rowCount() ? 'Employee record deleted.' : 'Employee record was not found.', $stmt->rowCount() ? 'success' : 'error');
header('Location: index.php'); exit;

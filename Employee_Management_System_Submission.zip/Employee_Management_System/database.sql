CREATE DATABASE IF NOT EXISTS employee_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE employee_management;

CREATE TABLE IF NOT EXISTS employees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT NULL,
    department VARCHAR(80) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    joining_date DATE NOT NULL,
    employment_status ENUM('Active','On Leave','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_department (department),
    INDEX idx_status (employment_status),
    INDEX idx_name (last_name, first_name)
);

INSERT IGNORE INTO employees
(employee_code, first_name, last_name, email, phone, department, designation, joining_date, employment_status)
VALUES
('EMP001','Aarav','Shah','aarav.shah@example.com','9876501001','IT','IT Support Executive','2024-04-15','Active'),
('EMP002','Mira','Patel','mira.patel@example.com','9876501002','Human Resources','HR Executive','2023-08-01','Active'),
('EMP003','Rohan','Mehta','rohan.mehta@example.com','9876501003','Finance','Accountant','2022-11-21','On Leave'),
('EMP004','Ananya','Rao','ananya.rao@example.com','9876501004','Operations','Operations Coordinator','2025-01-06','Active'),
('EMP005','Kabir','Fernandes','kabir.fernandes@example.com','9876501005','Sales','Sales Executive','2021-06-10','Inactive');

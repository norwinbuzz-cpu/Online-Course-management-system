<?php
require __DIR__ . '/config.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: null;
$employee = [
    'employee_code'=>'','first_name'=>'','last_name'=>'','email'=>'','phone'=>'',
    'department'=>'IT','designation'=>'','joining_date'=>date('Y-m-d'),'employment_status'=>'Active'
];
$isEdit = false;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM employees WHERE id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) { flash('Employee record not found.', 'error'); header('Location: index.php'); exit; }
    $employee = $found; $isEdit = true;
}
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT) ?: null;
    $isEdit = (bool)$id;
    foreach (['employee_code','first_name','last_name','email','phone','department','designation','joining_date','employment_status'] as $field) {
        $employee[$field] = trim((string)($_POST[$field] ?? ''));
    }
    if ($employee['employee_code'] === '') $errors[] = 'Employee ID is required.';
    if ($employee['first_name'] === '') $errors[] = 'First name is required.';
    if ($employee['last_name'] === '') $errors[] = 'Last name is required.';
    if (!filter_var($employee['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if ($employee['department'] === '') $errors[] = 'Department is required.';
    if ($employee['designation'] === '') $errors[] = 'Designation is required.';
    $date = DateTime::createFromFormat('Y-m-d', $employee['joining_date']);
    if (!$date || $date->format('Y-m-d') !== $employee['joining_date']) $errors[] = 'Enter a valid joining date.';
    if (!in_array($employee['employment_status'], ['Active','On Leave','Inactive'], true)) $errors[] = 'Choose a valid employment status.';

    if (!$errors) {
        try {
            if ($isEdit) {
                $stmt = $pdo->prepare('UPDATE employees SET employee_code=?, first_name=?, last_name=?, email=?, phone=?, department=?, designation=?, joining_date=?, employment_status=? WHERE id=?');
                $stmt->execute([$employee['employee_code'],$employee['first_name'],$employee['last_name'],$employee['email'],$employee['phone'] ?: null,$employee['department'],$employee['designation'],$employee['joining_date'],$employee['employment_status'],$id]);
                flash('Employee details updated successfully.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO employees (employee_code,first_name,last_name,email,phone,department,designation,joining_date,employment_status) VALUES (?,?,?,?,?,?,?,?,?)');
                $stmt->execute([$employee['employee_code'],$employee['first_name'],$employee['last_name'],$employee['email'],$employee['phone'] ?: null,$employee['department'],$employee['designation'],$employee['joining_date'],$employee['employment_status']]);
                flash('Employee added successfully.');
            }
            header('Location: index.php'); exit;
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') $errors[] = 'Employee ID or email already exists. Please use a unique value.';
            else $errors[] = 'Unable to save the employee record. Check the database configuration.';
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= $isEdit ? 'Edit' : 'Add' ?> Employee | PeopleDesk</title><link rel="stylesheet" href="assets/style.css"></head>
<body><aside class="sidebar"><a class="brand" href="index.php"><span class="brand-mark">P</span><span>PeopleDesk<small>EMPLOYEE PORTAL</small></span></a><div class="nav-label">WORKSPACE</div><a class="nav-link" href="index.php"><span>▦</span> Dashboard</a><a class="nav-link active" href="employee_form.php"><span>＋</span> Add employee</a><div class="sidebar-bottom"><div class="avatar">HR</div><div><strong>HR Administrator</strong><small>Local demo account</small></div></div></aside>
<main class="main"><header class="topbar"><div><a class="breadcrumb" href="index.php">Workspace / Employees /</a> <strong><?= $isEdit ? 'Edit employee' : 'Add employee' ?></strong></div><a class="reset-link" href="index.php">← Back to dashboard</a></header>
<section class="welcome"><div><div class="eyebrow">EMPLOYEE RECORDS</div><h1><?= $isEdit ? 'Update employee' : 'Add a new employee' ?></h1><p>Enter the employee details below. Fields marked * are required.</p></div></section>
<?php if ($errors): ?><div class="alert error"><strong>Please correct the following:</strong><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form class="form-panel" method="post" action="employee_form.php<?= $isEdit ? '?id='.(int)$id : '' ?>">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int)$id ?>"><?php endif; ?>
<h2>Basic information</h2><div class="form-grid">
<div><label for="employee_code">Employee ID *</label><input id="employee_code" name="employee_code" required maxlength="20" value="<?= e($employee['employee_code']) ?>" placeholder="e.g. EMP006"></div>
<div><label for="first_name">First name *</label><input id="first_name" name="first_name" required maxlength="80" value="<?= e($employee['first_name']) ?>"></div>
<div><label for="last_name">Last name *</label><input id="last_name" name="last_name" required maxlength="80" value="<?= e($employee['last_name']) ?>"></div>
<div><label for="email">Email address *</label><input id="email" name="email" type="email" required maxlength="160" value="<?= e($employee['email']) ?>" placeholder="name@example.com"></div>
<div><label for="phone">Phone number</label><input id="phone" name="phone" maxlength="30" value="<?= e($employee['phone']) ?>"></div>
<div><label for="department">Department *</label><select id="department" name="department" required><?php foreach (['IT','Human Resources','Finance','Operations','Sales','Marketing','Customer Support','Administration'] as $d): ?><option value="<?= e($d) ?>" <?= $employee['department']===$d?'selected':'' ?>><?= e($d) ?></option><?php endforeach; ?></select></div>
<div><label for="designation">Designation *</label><input id="designation" name="designation" required maxlength="100" value="<?= e($employee['designation']) ?>" placeholder="e.g. Support Executive"></div>
<div><label for="joining_date">Joining date *</label><input id="joining_date" name="joining_date" type="date" required value="<?= e($employee['joining_date']) ?>"></div>
<div><label for="employment_status">Employment status *</label><select id="employment_status" name="employment_status" required><?php foreach (['Active','On Leave','Inactive'] as $s): ?><option value="<?= e($s) ?>" <?= $employee['employment_status']===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
</div><div class="form-actions"><a class="cancel-btn" href="index.php">Cancel</a><button class="primary-btn" type="submit"><?= $isEdit ? 'Save changes' : 'Create employee' ?></button></div></form>
<footer class="footer">PeopleDesk Employee Management System <span>PHP · MySQL · HTML · CSS</span></footer></main></body></html>

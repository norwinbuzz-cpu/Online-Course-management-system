Capture screenshots after running the project locally. Recommended: dashboard.png, add_employee.png, validation.png, search_filter.png, edit_employee.png, delete_result.png.
Screenshots are not pre-generated because the PHP/MySQL application must be run with your local database to show genuine working results.

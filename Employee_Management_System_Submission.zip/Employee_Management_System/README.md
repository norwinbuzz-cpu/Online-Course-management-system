# Employee Management System (PHP + MySQL)

## Included features
- Dashboard statistics: total employees, active employees, departments, employees on leave
- Add, list, edit, delete employee records
- Search by employee ID, name, email, or designation
- Filter by department and employment status
- Server-side validation, prepared SQL statements, HTML escaping, CSRF token checks, and confirmation before deletion
- Responsive interface and sample records

## Requirements
- XAMPP / WAMP / MAMP, or PHP 8+ with MySQL/MariaDB
- PHP PDO MySQL extension enabled
- Modern web browser

## Installation with XAMPP
1. Extract the `Employee_Management_System` folder into `C:\xampp\htdocs\`.
2. Open XAMPP Control Panel and start **Apache** and **MySQL**.
3. Open `http://localhost/phpmyadmin/`.
4. Choose **Import**, select the supplied `database.sql`, and run the import.
5. Check `config.php`. The default XAMPP local configuration uses user `root` with an empty password. Change these values if your local MySQL configuration differs.
6. Open `http://localhost/Employee_Management_System/`.

## Working demonstration
- Dashboard: view the sample employee records and statistics.
- Add: select **Add employee**, fill required fields, and submit.
- Search/filter: use the directory controls.
- Edit: select **Edit** on any row.
- Delete: select **Delete** and confirm.

## Project files
- `index.php` — dashboard, employee directory, search, filters, statistics
- `employee_form.php` — create/update employee form and validation
- `delete_employee.php` — protected POST delete handler
- `config.php` — PDO connection, escaping, CSRF and flash-message helpers
- `database.sql` — database schema and sample data
- `assets/style.css` — responsive styling
- `PROJECT_REPORT.md` — report content for submission
- `screenshots/` — placeholder for screenshots captured from a running local installation

## Test cases
1. Dashboard loads with sample data and correct counts.
2. Add an employee with unique employee ID and email; record appears in the directory.
3. Submit without first name; browser/server validation should reject it.
4. Enter an invalid email; form should display a validation message.
5. Reuse an existing employee ID or email; duplicate should be rejected.
6. Search by employee name or code; matching records should be displayed.
7. Filter by department and status; matching records should be displayed.
8. Edit an employee's department; updated details should be shown.
9. Delete an employee and confirm; record should be removed.
10. Visit `delete_employee.php` directly using GET; it should redirect without deleting.

## Security and deployment note
This is an educational local demo, not a production-ready HR system. It does not include real authentication/authorization, audit logging, encrypted backups, or deployment hardening. Before using real employee data, add secure login and role-based access, HTTPS, access logging, privacy controls, backup/retention policies, and secure database credentials. Sample data is fictional.
